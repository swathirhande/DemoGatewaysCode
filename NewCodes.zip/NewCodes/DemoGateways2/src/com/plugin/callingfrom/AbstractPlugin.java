package com.plugin.callingfrom;

public abstract class AbstractPlugin {
	public abstract void start(String n);
}
