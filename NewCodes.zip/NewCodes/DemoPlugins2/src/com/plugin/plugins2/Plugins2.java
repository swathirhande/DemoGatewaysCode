package com.plugin.plugins2;

import com.plugin.callingfrom.AbstractPlugin;

public class Plugins2 extends AbstractPlugin {
	public static boolean a;
	static String c = null;

	@Override
	public void start(String n) {
		// TODO Auto-generated method stub
		System.out.print("0");

	}

}
