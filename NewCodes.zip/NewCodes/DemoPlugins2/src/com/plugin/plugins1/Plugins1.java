package com.plugin.plugins1;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.plugin.callingfrom.AbstractPlugin;

public class Plugins1 extends AbstractPlugin {

	@Override
	public void start(String n) {
		// TODO Auto-generated method stub
		int a;
		Pattern pattern = Pattern.compile("[^A-Za-z0-9]");
		Matcher match = pattern.matcher(n);
		boolean val = match.find();
		if (val == true) {
			a = 1;
			System.out.print("1");
		} else {
			a = 0;
			System.out.print(a);
		}

	}

}
